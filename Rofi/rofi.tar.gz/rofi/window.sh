rofi -no-lazy-grab -show window -theme window.rasi
