rofi -no-lazy-grab -show drun -theme launcher.rasi
