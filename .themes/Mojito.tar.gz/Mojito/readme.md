Tranq theme
